import React from 'react';
/*import img1 from '../images/Gamingstan1.png';*/
import './App.css';
/*import { NavLink } from 'react-router-dom';*/
import sli from '../images/slider.png';
import acc from '../images/acc.png';
function Home() {
  return (
    <div className='bg'>
      <div className='hm'>
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src={sli} alt="First slide" />
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="..." alt="Second slide" />
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="..." alt="Third slide" />
            </div>
          </div>
          {/**/}

          <section className='services py-3 ' id='services'>
            <div class="container">
              <div class="text-center my-5">
                <h1><span class="text-warning">Fresh Recomendation</span></h1>
                <hr class="w-25 m-auto" />
              </div>
              <div class="row" data-aos="zoom-in-up" data-aos-off="100">
                <div class="col-sm-12 col-md-4 col-lg-4 col-12">
                  <div class="card  text-dark ">
                    <div class="card-body">
                   
                      <h5 class="card-title">Account</h5>
                      <img className='acc-img' src={acc}></img>


                    </div>
                  </div>
                </div>



                <div class="col-sm-12 col-md-4 col-lg-4 col-12">
                  <div class="card">
                    <div class="card-body">
                  
                      <h5 class="card-title">Accounts</h5>
                      <img className='acc-img' src={acc}></img>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4 col-12">
                  <div class="card">
                    <div class="card-body">
                    
                      <h5 class="card-title">Account</h5>
                      <img className='acc-img' src={acc}></img>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        
      </section>
      {/**/}



    </div>
</div >
 
  
  </div >
  
    
);
}

export default Home;


