import React, { useState } from "react";
import "./App.css";
function Accounts() {
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");
  const [nameErr, setNameErr] = useState(false);
  const [titleErr, setTitleErr] = useState(false);
  function PublishHandle(e) {
    e.preventDefault();
  }
  function nameHandler(e) {
    let item = e.target.value;
    if (item.length < 3) {
      setNameErr(true);
    } else {
      setNameErr(false);
    }
    console.warn(e.target.value.length);
  }
  function titleHandler(e) {
    let item = e.target.value;
    if (item.length < 3) {
      setTitleErr(true);
    } else {
      setTitleErr(false);
    }
    console.warn(e.target.value.length);
  }
  return (
    <div className="back">
      <section className="sellaccount">
        <div className="conatiner mt-5">
          <div className="sellaccount-content">
            <div className="signup-form">
              <h2 className="form-title">Publish Your Ad</h2>
              <form
                className="register-form"
                id="register-form"
                onSubmit={PublishHandle}
              >
                <h1>Game</h1>
                <div className="form-group">
                  <input
                    type="Text"
                    name="game-type"
                    id="game-type"
                    placeholder="Game Name"
                    onChange={nameHandler}
                    autoComplete="off"
                  ></input>
                  {nameErr ? <span>InValid Name</span> : ""}
                </div>

                <div className="form-group">
                  <input
                    type="Text"
                    name="Ad-title"
                    id="Ad-title"
                    placeholder="Ad Title"
                    onChange={titleHandler}
                    autoComplete="off"
                  ></input>
                  {titleErr ? <span>InValid Title</span> : ""}
                </div>
                <div className="form-group">
                  <input
                    type="Text"
                    name="description"
                    id="description"
                    placeholder=" Ad Description"
                    autoComplete="off"
                  ></input>
                </div>
                <div className="form-group">
                  <input
                    type="Text"
                    name="email"
                    id="email"
                    placeholder="Location"
                    autoComplete="off"
                  ></input>
                </div>
                <div className="form-group">
                  <input
                    type="number"
                    name="email"
                    id="email"
                    placeholder="price"
                    autoComplete="off"
                  ></input>
                </div>

                <div className="form-group form-button">
                  <input
                    type="submit"
                    name="signup"
                    id="signup"
                    className="form-submit"
                    value="PUBLISH"
                  ></input>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Accounts;
