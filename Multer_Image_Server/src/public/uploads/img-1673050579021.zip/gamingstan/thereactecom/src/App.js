import React from "react";
import { BrowserRouter as Router, Routes, Route,Switch } from "react-router-dom";
/*import About from "./About";
import Home from "./Home";
import Products from "./Products";
import Contact from "./Contact";
import SingleProduct from "./SingleProduct";
import Accounts from "./Accounts";
import Cart from "./Cart";
import ErrorPage from "./ErrorPage"
import BasicForm from "./basicForm";*/
import Home from "./componenets/pages/Home";
import About from "./componenets/pages/About";
import Contact from "./componenets/pages/Contact";
import Login from "./componenets/pages/Login";
import Signup from "./componenets/pages/Signup";
import Sell from "./componenets/pages/Sell";
import Catagories from "./componenets/pages/Catagories";
import Accounts from "./componenets/pages/Accounts";
import Hardware from "./componenets/pages/Hardware";
import ForgotPassword from "./componenets/pages/ForgotPassword";
import "./App.css";
import Footer from "./componenets/pages/Footer";
import Reset from "./componenets/pages/Reset";
import Updated from "./componenets/pages/Updated";
import Addpackage from "./componenets/pages/Addpackage";
import Navbar from "./componenets/pages/Navbar";
import Editpackage from "./componenets/pages/Editpackage";
import Manageadd from "./componenets/pages/Manageadd";
/*import { Router } from "react-router-dom";*/
function App() {
  return (
    <div className="page-containerr">
      <div className="content-wrap">

     <Navbar/>
    <Router>
        {/**/}
        <switch>
        <Routes>
          <Route path="/" element={<Home/>}>
          </Route>
          <Route path="/home" element={<Home/>}>
          </Route>
          <Route path="/about" element={<About/>}>
          </Route>

          <Route path="/contact" element={<Contact/>}>
          </Route>

          <Route path="/catagories" element={<Catagories/>}>
          </Route>

          <Route path="/sell" element={<Sell/>}>
          </Route>

          <Route path="/login" element={<Login/>}>
          </Route>

          <Route path="/signup" element={<Signup/>}>
          </Route>

          <Route path="/accounts" element={<Accounts/>}>
          </Route>
          
          <Route path="/hardware" element={<Hardware/>}>
          </Route>

          <Route path="/forgotpassword" element={<ForgotPassword/>}>
          </Route>

          <Route path="/reset" element={<Reset/>}>
          </Route>

          <Route path="/updated" element={<Updated/>}>
          </Route>

          <Route path="/addpackage" element={<Addpackage/>}>
          </Route>

          <Route path="/editpackage" element={<Editpackage/>}>
          </Route>

          <Route path="/manageadd" element={<Manageadd/>}>
          </Route>
        </Routes>

        </switch>
      
    </Router>
    <Footer/>
    </div>
    
    </div>
    /* 
     <Router>
    <Routes>
      <Route path="/" element={<Home />}/>
      <Route path="/about" element={<About />}/>
      <Route path="/products" element={<Products />}/>
      <Route path="/contact" element={<Contact />}/>
      <Route path="/singleproduct/:id" element={<SingleProduct />}/>
      <Route path="/accounts" element={<Accounts />}/>
      <Route path="/cart" element={<Cart />}/>
      <Route path="/*" element={<ErrorPage />}/>
      <Route path="/basicForm" element={<BasicForm />}/>
      
    </Routes>
  </Router>

  
    */
  );
}

export default App;
