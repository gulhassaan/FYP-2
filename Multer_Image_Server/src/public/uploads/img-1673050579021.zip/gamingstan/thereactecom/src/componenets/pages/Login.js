import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import log from '../images/login.png'
import ema from '../images/email.png' 
import pas from '../images/password.png'
import "./App.css";

import Navbar from "./Nabvar1";
function Login() {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
const [userErr,setUserErr]=useState(false);
const [passErr,setPassErr]=useState(false);

  function LoginHandle(e) {
    if(user.length<7 || password.length<7)
    {
        alert("Enter more than 7")
    }
    else{
        alert("Login SuccessFully :)")
    }
    e.preventDefault();
  }
  function UserHandler(e){
    let item=e.target.value;
    if(item.length<7)
    {
        setUserErr(true)
    
    }
    else{
        setUserErr(false)
    }
    setUser(item)

  }
  function PasswordHandler(e){
    let item=e.target.value;
    if(item.length<7)
    {
        setPassErr(true)
    
    }
    else{
        setPassErr(false)
    }
    setPassword(item)
  }
  return (

    <section className="sign-in">
      <div className="conatiner mt-5">
        <div className="signin-content">
          <div className="signin-form">
            <img src={log}/>
            <h2 className="form-title">Login</h2>
            <form
              className="register-form"
              id="register-form"
              onClick={LoginHandle}
            >
          
              <div className="form-group">
                <label htmlFor="email">
                 {/* <i class="zmdi zmdi-email"></i>*/}
                  <img src={ema}></img>
                </label>
                
                <input
                  type="email"
                  name="email"
                  id="email"
                  
                  placeholder="Your Email"
                  onChange={UserHandler}
                ></input>
                
              </div>
              {userErr?<span className="text-err">user not valid</span>:""}
              <div className="form-group">
                <label htmlFor="password">
                  <img  className="pass-icon"  src={pas}></img>
                </label>
                <input
                  type="password"
                  name="passwrod"
                  id="password"
                  placeholder="Your Password"
                  onChange={PasswordHandler}
                ></input>
              </div>
              {passErr?<span  className="text-err">password not valid</span>:""}
              <div className="form-submit">
              <button className="verify">
              
              <NavLink to="/home" type="submit" className="formsubmit">
                  Login
                </NavLink>
  
              </button>
           
              </div>
            </form>
             <div className="signin-image">
              <NavLink to="/forgotpassword" className="signup-image-link">
                Forgot Password
              </NavLink>
             </div>
            <div className="signin-image">
              <NavLink to="/signup" className="signup-image-link">
                Create an Account
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </section>
    
  );
}

export default Login;
