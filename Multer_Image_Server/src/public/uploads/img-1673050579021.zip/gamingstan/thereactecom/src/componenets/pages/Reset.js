import React from "react";
import './App.css';
import { NavLink } from "react-router-dom";
import res from '../images/reset.png';
import pin from '../images/pin.png';
function Reset() {
  return (
  <section className="Forgot">
  <div className="conatiner mt-5">
    <div className="Forgot-content">
      <div className="signin-form">
        <img src={res}></img>
        <h2 className="form-title">Reset Password</h2>
        <form
          className="register-form"
          id="register-form"
          >
       <div className="form-group">
                <label htmlFor="password">
                  <img className="pass-icon" src={pin}></img>
                </label>
                <input
                  type="pin"
                  name="pin"
                  id="pin"
                  placeholder="Confirmation Pin"
                  autoComplete="off"
                ></input>
              </div>
        
          <div className="form-group">
                <label htmlFor="password">
                <img className="pass-icon" src={pin}></img>
                </label>
                <input
                  type="pin"
                  name="pin"
                  id="pin"
                  placeholder="Confirmation Pin"
                  autoComplete="off"
                ></input>
              </div>
         
          
          <div className="signin-image">
          <button className="confirm">

<NavLink to="/forgotpassword" className="signup-image-link">
    Back
  </NavLink>
</button>
            <button className="confirm">

            <NavLink to="/updated" className="signup-image-link">
                Confirm
              </NavLink>
            </button>
              
             </div>
        </form>
        
      </div>
    </div>
  </div>
</section>
  );
}
export default Reset;