import React from 'react';

function Contactus(){
return(
<div className='conatiner'>
    <div className='card mt-4'>
        <div className='card-body'>
           <h2>Contact</h2>
        </div>
    </div>
</div>
);
}

export default Contactus;