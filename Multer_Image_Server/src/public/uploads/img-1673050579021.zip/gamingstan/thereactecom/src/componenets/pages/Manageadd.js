import React from 'react'
import Navbar from './Navbar';
import './App.css';
import { NavLink } from 'react-router-dom';
import add from '../images/add1.png';
function Manageadd() {
  return (
    <div className='page-heading'>
      <Navbar/>
      
    <div class="pageheading">
  <h1>Manage Ad Featuring Packages</h1>
  </div>
<div>
<button className="manage-btn">
              <img className='pass-icon' src={add}/>
              <NavLink to="/login" className="manage-btn">
                  Add package
                </NavLink>
  
              </button>
  </div>
  <div className='head'>
  <h4>Current Packages</h4>
  </div>*
<div class="form1-container">

  <form className='form1'>
    <h3 className='hd'>Basic Package</h3>
    <p className='tt'>Featuring your ad for 7 days</p>
    <h4>RS  500</h4>
    <button className="pack-btn">
              
              <NavLink to="/edit" type="submit" className="formsubmit">
                  Edit
                </NavLink>
  
              </button>
              <button className="pack-btn">
              
              <NavLink to="/delete" type="submit" className="formsubmit">
                  Delete
                </NavLink>
  
              </button>
  </form>
  <form className='form2'>
  <h3 className='hd'>Basic Package</h3>
    <p className='tt'>Featuring your ad for 7 days</p>
    <h4>RS  500</h4>
    <button className="pack-btn">
              
              <NavLink to="/edit" type="submit" className="formsubmit">
                  Edit
                </NavLink>
  
              </button>
              <button className="pack-btn">
              
              <NavLink to="/delete" type="submit" className="formsubmit">
                  Delete
                </NavLink>
  
              </button>
    
  </form>
  <form className='form3'>
  <h3 className='hd'>Basic Package</h3>
    <p className='tt'>Featuring your ad for 7 days</p>
    <h4>RS  500</h4>
    <button className="pack-btn">
              
              <NavLink to="/edit" type="submit" className="formsubmit">
                  Edit
                </NavLink>
  
              </button>
              <button className="pack-btn">
              
              <NavLink to="/delete" type="submit" className="formsubmit">
                  Delete
                </NavLink>
  
              </button>
 
  </form>
</div>

</div>

  )
}

export default Manageadd;