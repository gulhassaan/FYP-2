import React from 'react';
import './App.css';
import img1 from '../images/Gamingstan1.png';
function Sell(){
return(
     <div className='home-page'>
     <img className='home-img' id='home-img' src={img1} alt="" />
     
     <div className='centered'>
    
     <option class="dropdown-toggle " data-bs-toggle="dropdown" role="button">Catagories</option>
     
         <ul class="dropdown-menu bg-secondary p-4">
           <li><a class="dropdown-item " href="/accounts">Accouts</a></li>
           <li><a class="dropdown-item" href="/hardware">Hardware</a></li>
           
         </ul>
         </div>
     
        
  </div>
    
   

  
);
}

export default Sell;