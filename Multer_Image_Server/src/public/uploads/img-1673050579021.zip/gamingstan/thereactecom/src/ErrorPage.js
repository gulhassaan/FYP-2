import React from 'react'

const ErrorPage = () => {
  return (
    <div>
      <h1>No Such Page is not available In Gamingstan</h1>
    </div>
  )
}

export default ErrorPage
