import React from 'react';
import './App.css';
function Hardware(){
return(
    
  <div className='back'>
        
   
  <section className='sell-main' >
      
      <div className='conatiner mt-5'>
          
  <div className='sell-main-content'>
      
  
      <div className='signup-form'>
          
  <h2 className='form-title'>Publish Your Ad</h2>
  <form className='register-form' id='register-form'>
      
  <h1>Hardware</h1>
  <div className='form-group'>
         
          <input type="Text" name='game-type' id='game-type' placeholder='Hardware Name' autoComplete='off' >
          
          </input>
      </div>
  
      <div className='form-group'>
         
          <input type="Text" name='Ad-title' id='Ad-title' placeholder='Ad Title' autoComplete='off' >
          
          </input>
      </div>
      <div className='form-group'>
         
        
         <textarea type="Text" name='description' id='description' placeholder=' Ad Description' autoComplete='off'></textarea>
     </div>
  <div className='form-group'>
         
          <input type="Text" name='email' id='email' placeholder='Location' autoComplete='off' >
          
          </input>
      </div>
      <div className='form-group'>
         
         <input type="number" name='email' id='email' placeholder='price' autoComplete='off'></input>
     </div>
  
      
  
     <div className='form-group form-button'>
      <input type="submit" name='signup' id='signup' className='form-submit' value="PUBLISH"></input>
     </div>
     
  </form>
  
      </div>
  </div>
  
      </div>
      
  </section>
  
  </div>
);
}

export default Hardware;