import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./App.css";

function Signup() {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [cpassword, setcPassword] = useState("");
  const [number, setNumber] = useState("");
  const [userErr,setUserErr]=useState(false);
  const [passErr,setPassErr]=useState(false);
  const [numErr,setNumErr]=useState(false);
  const [cpassErr,setcPassErr]=useState(false);
  function SignupHandle(e) {
    if(user.length<4 || password.length<4 )
    {
     alert("type correct values")   
    }
    else if(password!=cpassword){
alert("Password did not match")
    }
    else if(number.length>10){
alert("number error")
    }
    else{
        alert("Sign up SuccessFully")
    }
    e.preventDefault();
  }
   function userHandler(e){
    let item=e.target.value;
    if(item.length<3)
    {
        setUserErr(true)
    }
    else{
        setUserErr(false)
    }
    setUser(item)
  }



  function numHandler(e){
    let item=e.target.value;
    if(item.length=11)
    {
        setNumErr(true)
    }
    else{
        setNumErr(false)
    }
    setNumber(item)
  }




  function passHandler(e){
    let item=e.target.value;
    if(item.length<7)
    {
        setPassErr(true)
    }
    else{
        setPassErr(false)
    }
    setPassword(item)
  }


  function cpassHandler(e){
    let item=e.target.value;
    if(item.length<3)
    {
        setcPassErr(true)
    }
    else{
        setcPassErr(false)
    }
    setcPassword(item)
  }


  return (
    <section className="signup">
      <div className="conatiner mt-5">
        <div className="signup-content">
          <div className="signup-form">
            <h2 className="form-title">signup</h2>
            <form
              className="register-form"
              id="register-form"
              onSubmit={SignupHandle}
            >
              <div className="form-group">
                <label htmlFor="name">
                  <i class="zmdi zmdi-account-circle"></i>
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  placeholder="Your Name"
                ></input>
              </div>

              <div className="form-group">
                <label htmlFor="email">
                  <i class="zmdi zmdi-email"></i>
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Your Email"
                  onChange={userHandler}
                  autoComplete="off"
                ></input>
                
              </div>
              {userErr?<span className="text-err">email not valid</span>:""}
              <div className="form-group">
                <label htmlFor="phone">
                  <i class="zmdi zmdi-phone"></i>
                </label>
                <input
                  type="text"
                  name="phone"
                  id="phone"
                  placeholder="Your Number"
                  onChange={numHandler}
                ></input>
              </div>
 {numErr?<span className="text-err">number not valid</span>:""}
              <div className="form-group">
                <label htmlFor="password">
                  <i class="zmdi zmdi-lock"></i>
                </label>
                <input
                  type="password"
                  name="passwrod"
                  id="password"
                  placeholder="Your Password"
                  onChange={passHandler}
                  autoComplete="off"
                ></input>
              </div>
              {passErr?<span className="text-err">password not valid</span>:""}
              <div className="form-group">
                <label htmlFor="cpassword">
                  <i class="zmdi zmdi-lock"></i>
                </label>
                <input
                  type="password"
                  name="cpasswrod"
                  id="cpassword"
                  placeholder=" Confirm Your Password"
                  onChange={cpassHandler}
                ></input>
              </div>
              {cpassErr?<span className="text-err"> password does not mach</span>:""}
              <div className="form-submit">
              <button className="verify">
              
              <NavLink  type="submit" className="formsubmit">
                  Register
                </NavLink>
  
              </button>
           
              </div>
            </form>
            <div className="signup-image">
              <NavLink to="/login" className="signup-image-link">
                
                Already Registered
              </NavLink>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Signup;

