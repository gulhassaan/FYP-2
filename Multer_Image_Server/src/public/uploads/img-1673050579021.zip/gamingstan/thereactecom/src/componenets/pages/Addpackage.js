import React from 'react'
import './App.css';
import add from '../images/addpackage.png';
import det from '../images/details.png';
import pri from '../images/price.png';
import { NavLink } from 'react-router-dom';
import ad1 from '../images/addpackage1.png';
function Addpackage() {
  return (
    <section className="Add-package">
  <div className="conatiner mt-5">
    <div className="Add-package-content">
      <div className="signin-form">
        <img src={ad1}></img>
        <h2 className="form-title">Add Package</h2>
        <form
          className="register-form"
          id="register-form"
          >
      
          <div className="form-group">
            <label htmlFor="">
              <img className='pass-icon' src={add}></img>
            </label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Package Name "
              ></input>
            
          </div>
          <div className="form-group">
                <label htmlFor="password">
                  <img className="pass-icon" src={det}></img>
                </label>
                <input
                  type="pin"
                  name="pin"
                  id="pin"
                  placeholder="Details"
                  autoComplete="off"
                ></input>
              </div>
         
          
              <div className="form-group">
                <label htmlFor="password">
                  <img className="pass-icon" src={pri}></img>
                </label>
                <input
                  type="pin"
                  name="pin"
                  id="pin"
                  placeholder="Price"
                  autoComplete="off"
                ></input>
              </div>
         

          <div className="signin-image">
            <button className="verify">
            <NavLink to="#" className="signup-image-link">
                Add
              </NavLink>

            </button>
             
             </div>
        </form>
        
      </div>
    </div>
  </div>
</section>
  )
}

export default Addpackage