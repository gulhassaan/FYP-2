import React from "react";
import './App.css';
import { NavLink } from "react-router-dom";
import forg from '../images/forgot.png';
import ema from '../images/email.png';
import pin from '../images/pin.png';
function ForgotPassword() {
  return (
  <section className="Forgot">
  <div className="conatiner mt-5">
    <div className="Forgot-content">
      <div className="signin-form">
        <img src={forg}></img>
        <h2 className="form-title">Forgot Password</h2>
        <form
          className="register-form"
          id="register-form"
          >
      
          <div className="form-group">
            <label htmlFor="email">
              <img src={ema}></img>
            </label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Your Email"
              ></input>
            
          </div>
          <div className="form-group">
                <label htmlFor="password">
                  <img className="pass-icon" src={pin}></img>
                </label>
                <input
                  type="pin"
                  name="pin"
                  id="pin"
                  placeholder="Confirmation Pin"
                  autoComplete="off"
                ></input>
              </div>
         
          
          <div className="signin-image">
          <button className="verify">
              
              <NavLink to="/login" className="signup-image-link">
                  Back
                </NavLink>
  
              </button>
            <button className="verify">
              
            <NavLink to="/reset" className="signup-image-link">
                verify
              </NavLink>

            </button>
             
             </div>
        </form>
        
      </div>
    </div>
  </div>
</section>
  );
}
export default ForgotPassword;