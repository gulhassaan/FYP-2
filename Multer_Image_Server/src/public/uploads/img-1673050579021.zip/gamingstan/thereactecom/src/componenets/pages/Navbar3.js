
import React, { useState } from "react";
import './App.css';
import logo1 from '../images/logo.png';
const Navbar3 = () => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="Navbar">
<img className="logo1-nav" src={logo1}></img>
<div className="nav-items1">
<a href="/home"><b>Admin</b> </a>
        <a href="/about"> <b>Ads</b> </a>
        <a href="/service"><b>About Us</b> </a>
        <a href="/contact"><b>Contact Us</b> </a>
</div>
        <div className={`nav-items ${isOpen && "open"}`}>
        <a href="/sell"> <b>Sell</b></a>
        <a href="/login"> <b>Login</b></a>
        <a href="/signup"><b>Signup</b></a>
        
      </div>
      
    
      <div
        className={`nav-toggle ${isOpen && "open"}`}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="bar"></div>
      </div>
    </div>
  );
};

export default Navbar3;